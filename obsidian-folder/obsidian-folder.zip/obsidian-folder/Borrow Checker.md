The borrow checker is the workhorse behind the safety guarantees of [[Rust]]. The best description of it comes from the Rust book itself, which is meant to introduce it to people learning Rust.

The BC can be ignored by throwing code into an [[Unsafe Rust|unsafe block]].
