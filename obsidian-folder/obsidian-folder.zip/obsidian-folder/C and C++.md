C is pretty much the most powerful language there is.
This is due to the fact that you can just do whatever you want with the process memory. 
While this sounds great, it leads to many security problems.
