Here we present [[C and C++]] code along with some equivalent [[Rust]] code. 
![[overflow-fail.png]]
![[overflow-win.png]]
This is a fail of the [[Borrow Checker]]: 
I will keep this in the paper to make a point--some things are not possible in safe Rust. To actually compile this would need to be reworked or in [[Unsafe Rust]].
![[rust-overflow.png]]


