This is the second language inside of Rust where you can pretty much do whatever with memory. Sometime its necessary to complete safe tasks. 
[[unsafe-rust.pdf]]
