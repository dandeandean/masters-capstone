Rust is a relatively new language compared with [[C and C++]], and offers similar speeds to them #citation-needed.   The problem is that this language is much more complex than C++, as it offers a completely new concept: [[Borrow Checker|The Borrow Checker]]. This Borrow Checker (BC) allows for memory [[Safety Features in Rust |Safety Guarantees]] at compile time. 

